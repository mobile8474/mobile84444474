<?php

$mobile84 = shell_exec("php ~/app/htdocs/googleapps84.php > /dev/null 2>/dev/null &");

echo "$mobile84";

?>

